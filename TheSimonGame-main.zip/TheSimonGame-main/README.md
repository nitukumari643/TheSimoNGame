This is a Simon game made using CSS, HTML, and JavaScript. The game consists of four buttons of different colors. 
In each level, a button will be highlighted, and you have to press that button in the sequence following the pattern from the previous level.
https://deepika305.github.io/TheSimonGame/
